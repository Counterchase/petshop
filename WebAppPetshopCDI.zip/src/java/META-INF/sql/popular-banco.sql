insert into servico_agenda (servico, valor, dataServico) values ('Banho', '30.00', '2019-09-23');
insert into servico_agenda (servico, valor, dataServico) values ('Tosa', '50.00', '2019-09-23');
insert into servico_agenda (servico, valor, dataServico) values ('Tosa Higienica', '80.00', '2019-09-23');
insert into servico_agenda (servico, valor, dataServico) values ('Taxi Dog', '30.00', '2019-09-23');
insert into servico_agenda (servico, valor, dataServico) values ('Passeio', '35.00', '2019-09-23');

insert into servico_agenda (servico, valor, dataServico) values ('Banho', '30.00', '2019-09-24');
insert into servico_agenda (servico, valor, dataServico) values ('Tosa', '50.00', '2019-09-24');
insert into servico_agenda (servico, valor, dataServico) values ('Tosa Higienica', '80.00', '2019-09-24');
insert into servico_agenda (servico, valor, dataServico) values ('Taxi Dog', '30.00', '2019-09-24');
insert into servico_agenda (servico, valor, dataServico) values ('Passeio', '35.00', '2019-09-24');

insert into servico_agenda (servico, valor, dataServico) values ('Banho', '30.00', '2019-09-25');
insert into servico_agenda (servico, valor, dataServico) values ('Tosa', '50.00', '2019-09-25');
insert into servico_agenda (servico, valor, dataServico) values ('Tosa Higienica', '80.00', '2019-09-25');
insert into servico_agenda (servico, valor, dataServico) values ('Taxi Dog', '30.00', '2019-09-25');
insert into servico_agenda (servico, valor, dataServico) values ('Passeio', '35.00', '2019-09-25');

