package br.com.petshop.model;

public class Autenticacao {
    public String autenticar(String usuario, String senha){
        return "Bem Vindo.: " + usuario; 
    }
}
